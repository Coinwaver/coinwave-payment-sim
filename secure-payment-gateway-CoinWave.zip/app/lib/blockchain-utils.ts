export function generateBlockchainHash(transactionId: string, amount: string, method: string): string {
  // Simulate blockchain hash generation
  const data = `${transactionId}-${amount}-${method}-${Date.now()}`
  return `0x${btoa(data)
    .replace(/[^a-zA-Z0-9]/g, "")
    .toLowerCase()
    .substring(0, 64)}`
}

export async function verifyBlockchainTransaction(transactionId: string) {
  // Simulate blockchain verification delay
  await new Promise((resolve) => setTimeout(resolve, 3000))

  // Generate mock blockchain data
  return {
    hash: generateBlockchainHash(transactionId, "100", "card"),
    blockNumber: Math.floor(Math.random() * 1000000) + 18000000,
    confirmations: Math.floor(Math.random() * 50) + 15,
    gasUsed: Math.floor(Math.random() * 50000) + 21000,
    network: "Ethereum Mainnet",
    timestamp: new Date().toISOString(),
    verified: true,
  }
}

export function encryptSensitiveData(data: string): string {
  // Simulate encryption (in production, use proper encryption)
  return btoa(data).split("").reverse().join("")
}

export function decryptSensitiveData(encryptedData: string): string {
  // Simulate decryption
  return atob(encryptedData.split("").reverse().join(""))
}
