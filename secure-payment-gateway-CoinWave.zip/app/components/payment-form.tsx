"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { CreditCard, Wallet, Bitcoin, Lock, CheckCircle } from "lucide-react"
import { processPayment } from "../lib/payment-processor"
import { generateBlockchainHash } from "../lib/blockchain-utils"

interface PaymentFormProps {
  onTransactionCreated: (transactionId: string) => void
}

export default function PaymentForm({ onTransactionCreated }: PaymentFormProps) {
  const [paymentMethod, setPaymentMethod] = useState("card")
  const [amount, setAmount] = useState("")
  const [isProcessing, setIsProcessing] = useState(false)
  const [transactionResult, setTransactionResult] = useState<any>(null)
  const [securityLevel, setSecurityLevel] = useState("high")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsProcessing(true)

    try {
      // Simulate payment processing with blockchain integration
      const transactionId = `tx_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
      const blockchainHash = generateBlockchainHash(transactionId, amount, paymentMethod)

      const result = await processPayment({
        transactionId,
        amount: Number.parseFloat(amount),
        paymentMethod,
        securityLevel,
        blockchainHash,
      })

      setTransactionResult(result)
      onTransactionCreated(transactionId)

      // Store transaction in localStorage for demo
      const transactions = JSON.parse(localStorage.getItem("transactions") || "[]")
      transactions.unshift({
        id: transactionId,
        amount: Number.parseFloat(amount),
        method: paymentMethod,
        status: result.status,
        timestamp: new Date().toISOString(),
        blockchainHash,
        securityLevel,
      })
      localStorage.setItem("transactions", JSON.stringify(transactions))
    } catch (error) {
      setTransactionResult({ status: "failed", error: "Payment processing failed" })
    } finally {
      setIsProcessing(false)
    }
  }

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <style jsx>{`
  @keyframes wave {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    25% { transform: translateY(-5px) rotate(1deg); }
    50% { transform: translateY(-3px) rotate(0deg); }
    75% { transform: translateY(-7px) rotate(-1deg); }
  }
  
  @keyframes ripple {
    0% { transform: scale(1); opacity: 1; }
    100% { transform: scale(1.4); opacity: 0; }
  }
  
  .wave-animation {
    animation: wave 3s ease-in-out infinite;
  }
  
  .ripple-animation {
    animation: ripple 2s ease-out infinite;
  }
`}</style>
      <Card className="bg-gradient-to-br from-cyan-50/50 via-blue-50/30 to-teal-50/50 border-cyan-200/50 shadow-lg shadow-cyan-100/50">
        <CardHeader>
          <CardTitle className="flex items-center gap-3 text-cyan-700 font-medium">
            <div className="relative">
              <img src="/images/aquatic-logo.png" alt="CoinWave Logo" className="h-8 w-8 animate-pulse" />
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/20 to-blue-500/20 rounded-full animate-ping"></div>
            </div>
            <span className="bg-gradient-to-r from-cyan-600 via-blue-600 to-teal-600 bg-clip-text text-transparent animate-pulse">
              CoinWave
            </span>
          </CardTitle>
          <CardDescription className="text-cyan-600/80">
            Experience the future of payments with CoinWave's blockchain-verified transactions flowing like ocean
            currents
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <Label className="text-base font-medium">Payment Method</Label>
              <RadioGroup
                value={paymentMethod}
                onValueChange={setPaymentMethod}
                className="grid grid-cols-3 gap-4 mt-2"
              >
                <div>
                  <RadioGroupItem value="card" id="card" className="peer sr-only" />
                  <Label
                    htmlFor="card"
                    className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <CreditCard className="mb-3 h-6 w-6" />
                    Credit Card
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="crypto" id="crypto" className="peer sr-only" />
                  <Label
                    htmlFor="crypto"
                    className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <Bitcoin className="mb-3 h-6 w-6" />
                    Cryptocurrency
                  </Label>
                </div>
                <div>
                  <RadioGroupItem value="wallet" id="wallet" className="peer sr-only" />
                  <Label
                    htmlFor="wallet"
                    className="flex flex-col items-center justify-between rounded-lg border-2 border-muted bg-popover p-4 hover:bg-accent hover:text-accent-foreground peer-data-[state=checked]:border-primary [&:has([data-state=checked])]:border-primary cursor-pointer"
                  >
                    <Wallet className="mb-3 h-6 w-6" />
                    Digital Wallet
                  </Label>
                </div>
              </RadioGroup>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label htmlFor="amount">Amount (USD)</Label>
                <Input
                  id="amount"
                  type="number"
                  step="0.01"
                  min="0.01"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder="0.00"
                  required
                />
              </div>
              <div>
                <Label htmlFor="security">Security Level</Label>
                <Select value={securityLevel} onValueChange={setSecurityLevel}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="standard">Standard</SelectItem>
                    <SelectItem value="high">High Security</SelectItem>
                    <SelectItem value="maximum">Maximum Security</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            {paymentMethod === "card" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="cardNumber">Card Number</Label>
                  <Input id="cardNumber" placeholder="1234 5678 9012 3456" />
                </div>
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <Label htmlFor="expiry">Expiry</Label>
                    <Input id="expiry" placeholder="MM/YY" />
                  </div>
                  <div>
                    <Label htmlFor="cvv">CVV</Label>
                    <Input id="cvv" placeholder="123" />
                  </div>
                  <div>
                    <Label htmlFor="zip">ZIP Code</Label>
                    <Input id="zip" placeholder="12345" />
                  </div>
                </div>
              </div>
            )}

            {paymentMethod === "crypto" && (
              <div className="space-y-4">
                <div>
                  <Label htmlFor="cryptoType">Cryptocurrency</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Select cryptocurrency" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="btc">Bitcoin (BTC)</SelectItem>
                      <SelectItem value="eth">Ethereum (ETH)</SelectItem>
                      <SelectItem value="usdc">USD Coin (USDC)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label htmlFor="walletAddress">Wallet Address</Label>
                  <Input id="walletAddress" placeholder="0x..." />
                </div>
              </div>
            )}

            <Button type="submit" className="w-full" disabled={isProcessing || !amount}>
              {isProcessing ? (
                <>Processing Payment...</>
              ) : (
                <>
                  <Lock className="mr-2 h-4 w-4" />
                  Process Secure Payment
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Security Features</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium">End-to-End Encryption</p>
                <p className="text-sm text-muted-foreground">AES-256 encryption for all data</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium">Blockchain Verification</p>
                <p className="text-sm text-muted-foreground">Immutable transaction records</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium">PCI DSS Compliant</p>
                <p className="text-sm text-muted-foreground">Industry standard security</p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <div>
                <p className="font-medium">Multi-Factor Authentication</p>
                <p className="text-sm text-muted-foreground">Additional security layers</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {transactionResult && (
          <Alert
            className={
              transactionResult.status === "success" ? "border-green-200 bg-green-50" : "border-red-200 bg-red-50"
            }
          >
            <AlertDescription className="flex items-center gap-2">
              {transactionResult.status === "success" ? (
                <>
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Payment processed successfully! Transaction ID: {transactionResult.transactionId}</span>
                </>
              ) : (
                <>
                  <span className="text-red-600">Payment failed: {transactionResult.error}</span>
                </>
              )}
            </AlertDescription>
          </Alert>
        )}
      </div>
    </div>
  )
}
