"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import PaymentForm from "./components/payment-form"
import TransactionHistory from "./components/transaction-history"
import BlockchainVerification from "./components/blockchain-verification"
import { Shield, CreditCard, History, Link } from "lucide-react"

export default function PaymentGateway() {
  const [activeTransaction, setActiveTransaction] = useState<string | null>(null)

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Shield className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">SecureChain Pay</h1>
          </div>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Advanced payment gateway with blockchain verification, multi-layer security, and real-time transaction
            monitoring
          </p>
        </div>

        <Tabs defaultValue="payment" className="w-full">
          <TabsList className="grid w-full grid-cols-3 mb-8">
            <TabsTrigger value="payment" className="flex items-center gap-2">
              <CreditCard className="h-4 w-4" />
              Payment
            </TabsTrigger>
            <TabsTrigger value="history" className="flex items-center gap-2">
              <History className="h-4 w-4" />
              History
            </TabsTrigger>
            <TabsTrigger value="blockchain" className="flex items-center gap-2">
              <Link className="h-4 w-4" />
              Blockchain
            </TabsTrigger>
          </TabsList>

          <TabsContent value="payment">
            <PaymentForm onTransactionCreated={setActiveTransaction} />
          </TabsContent>

          <TabsContent value="history">
            <TransactionHistory />
          </TabsContent>

          <TabsContent value="blockchain">
            <BlockchainVerification transactionId={activeTransaction} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
