"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Link, CheckCircle, Clock, Shield, Hash } from "lucide-react"
import { verifyBlockchainTransaction } from "../lib/blockchain-utils"

interface BlockchainVerificationProps {
  transactionId: string | null
}

export default function BlockchainVerification({ transactionId }: BlockchainVerificationProps) {
  const [verificationStatus, setVerificationStatus] = useState<"idle" | "verifying" | "verified" | "failed">("idle")
  const [verificationProgress, setVerificationProgress] = useState(0)
  const [blockchainData, setBlockchainData] = useState<any>(null)

  const startVerification = async () => {
    if (!transactionId) return

    setVerificationStatus("verifying")
    setVerificationProgress(0)

    // Simulate blockchain verification process
    const steps = [
      { name: "Connecting to blockchain network", duration: 1000 },
      { name: "Validating transaction hash", duration: 1500 },
      { name: "Checking block confirmations", duration: 2000 },
      { name: "Verifying digital signatures", duration: 1000 },
      { name: "Finalizing verification", duration: 500 },
    ]

    let progress = 0
    for (const step of steps) {
      await new Promise((resolve) => setTimeout(resolve, step.duration))
      progress += 20
      setVerificationProgress(progress)
    }

    try {
      const result = await verifyBlockchainTransaction(transactionId)
      setBlockchainData(result)
      setVerificationStatus("verified")
    } catch (error) {
      setVerificationStatus("failed")
    }
  }

  useEffect(() => {
    if (transactionId && verificationStatus === "idle") {
      startVerification()
    }
  }, [transactionId])

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Link className="h-5 w-5 text-blue-600" />
            Blockchain Verification
          </CardTitle>
          <CardDescription>Real-time verification of transaction on the blockchain network</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {!transactionId ? (
            <Alert>
              <AlertDescription>Process a payment to see blockchain verification in action</AlertDescription>
            </Alert>
          ) : (
            <>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Verification Status</span>
                  <Badge
                    className={
                      verificationStatus === "verified"
                        ? "bg-green-100 text-green-800"
                        : verificationStatus === "verifying"
                          ? "bg-blue-100 text-blue-800"
                          : verificationStatus === "failed"
                            ? "bg-red-100 text-red-800"
                            : "bg-gray-100 text-gray-800"
                    }
                  >
                    {verificationStatus === "verified" && <CheckCircle className="mr-1 h-3 w-3" />}
                    {verificationStatus === "verifying" && <Clock className="mr-1 h-3 w-3" />}
                    {verificationStatus.charAt(0).toUpperCase() + verificationStatus.slice(1)}
                  </Badge>
                </div>

                {verificationStatus === "verifying" && (
                  <div className="space-y-2">
                    <Progress value={verificationProgress} className="w-full" />
                    <p className="text-sm text-muted-foreground">Verifying transaction on blockchain network...</p>
                  </div>
                )}
              </div>

              {blockchainData && (
                <div className="space-y-4 border-t pt-4">
                  <h4 className="font-medium flex items-center gap-2">
                    <Shield className="h-4 w-4 text-green-600" />
                    Blockchain Details
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Block Number:</span>
                      <p className="font-mono text-muted-foreground">{blockchainData.blockNumber}</p>
                    </div>
                    <div>
                      <span className="font-medium">Confirmations:</span>
                      <p className="text-muted-foreground">{blockchainData.confirmations}</p>
                    </div>
                    <div>
                      <span className="font-medium">Gas Used:</span>
                      <p className="text-muted-foreground">{blockchainData.gasUsed}</p>
                    </div>
                    <div>
                      <span className="font-medium">Network:</span>
                      <p className="text-muted-foreground">{blockchainData.network}</p>
                    </div>
                  </div>
                  <div>
                    <span className="font-medium flex items-center gap-2">
                      <Hash className="h-4 w-4" />
                      Transaction Hash:
                    </span>
                    <p className="font-mono text-xs text-muted-foreground break-all mt-1">{blockchainData.hash}</p>
                  </div>
                </div>
              )}

              <Button onClick={startVerification} disabled={verificationStatus === "verifying"} className="w-full">
                {verificationStatus === "verifying" ? "Verifying..." : "Re-verify Transaction"}
              </Button>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Blockchain Network Status</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-green-600">99.9%</div>
              <div className="text-sm text-muted-foreground">Network Uptime</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-blue-600">2.3s</div>
              <div className="text-sm text-muted-foreground">Avg Block Time</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-purple-600">15</div>
              <div className="text-sm text-muted-foreground">Confirmations</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-orange-600">$0.02</div>
              <div className="text-sm text-muted-foreground">Avg Gas Fee</div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
